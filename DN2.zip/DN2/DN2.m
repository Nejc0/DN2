% Domača naloga 2

clear; clc;

fid = fopen('vozlisca_temperature_dn2_11.txt','r');
fgetl(fid);
vr = fgetl(fid); Nx = sscanf(vr,'st. koordinat v x-smeri: %f');
vr = fgetl(fid); Ny = sscanf(vr,'st. koordinat v y-smeri: %f');
vr = fgetl(fid); Nv = sscanf(vr,'st. vseh vozlisc: %f');

podatki = readmatrix('vozlisca_temperature_dn2_11.txt','NumHeaderLines',4);
x = podatki(:,1);
y = podatki(:,2);
T = podatki(:,3);
fclose(fid);

fid = fopen('celice_dn2_11.txt','r');
fgetl(fid);
vr = fgetl(fid); Nc = sscanf(vr,'st. celic: %f');
celice = readmatrix('celice_dn2_11.txt','NumHeaderLines',2);
fclose(fid);

xu = unique(x);
yu = unique(y);
Tmat = reshape(T,[Nx,Ny])';

x_del = 0.403;
y_del = 0.503;

tic;
F1 = scatteredInterpolant(x,y,T,'linear');
T1 = F1(x_del,y_del);
t1 = toc;

fprintf("Scattered: %.6f °C (%.6f s)\n", T1, t1);

tic;
F2 = griddedInterpolant({yu,xu},Tmat,'linear');
T2 = F2(y_del,x_del);
t2 = toc;

fprintf("Gridded:   %.6f °C (%.6f s)\n", T2, t2);

tic;
ix = find(xu <= x_del,1,'last');
iy = find(yu <= y_del,1,'last');

x1 = xu(ix); x2 = xu(ix+1);
y1 = yu(iy); y2 = yu(iy+1);

T11 = Tmat(iy,ix);
T21 = Tmat(iy,ix+1);
T12 = Tmat(iy+1,ix);
T22 = Tmat(iy+1,ix+1);

Tx1 = T11 + (T21 - T11) * ((x_del - x1) / (x2 - x1));
Tx2 = T12 + (T22 - T12) * ((x_del - x1) / (x2 - x1));
T3 = Tx1 + (Tx2 - Tx1) * ((y_del - y1) / (y2 - y1));

t3 = toc;

fprintf("Bilinearna:  %.6f °C (%.6f s)\n", T3, t3);

[Tmax, ind] = max(T);
fprintf("Tmax = %.6f °C pri (%.6f , %.6f)\n", Tmax, x(ind), y(ind));